import React from 'react';
import { BrowserRouter as Router, Route, Routes as ReactRoutes } from 'react-router-dom';
import Home from './pages/Home';
import NotFound from './pages/NotFound';
import WorkerHome from './pages/worker/WorkerHome';
import WorkerRegister from './pages/worker/Register';
import WorkerDetails from './components/worker/WorkerDetails';
import WorkerProfile from './pages/worker/WorkerProfile';

import EmployerHome from './pages/employer/EmployerHome';
import EmployerRegister from './pages/employer/EmployerRegister';
import EmployerProfile from './pages/employer/EmployerProfile';
import EmployerLogin from './pages/employer/EmployerLogin';


import Register from './pages/Register';
import Login from './pages/Login';

import WorkerLogin from './pages/worker/WorkerLogin';
import AboutUs from './pages/AboutUs';
import EmployerDetails from './components/EmployerDetails';

const AppRoutes = () => {
  return (
    <ReactRoutes>
      <Route path="/" element={<Home />} />

      <Route path='/worker' element={<WorkerHome />} />
      <Route path='/worker/login' element={<WorkerLogin />} />
      <Route path='/worker/register' element={<WorkerRegister />} />
      <Route path='/worker/profile' element={<WorkerProfile />} />

      <Route path='/employer' element={<EmployerHome />} />
      <Route path='/employer/login' element={<EmployerLogin />} />
      <Route path='/employer/register' element={<EmployerRegister/>} />
      <Route path='/employer/profile' element={<EmployerProfile />} />

      <Route path='/employer/login' element={<EmployerLogin/>} />
      <Route path='/register' element={<Register />} /> 
      <Route path='/login' element={<Login />} />
      <Route path='/employer/:employerId' element={<EmployerDetails />} />
      <Route path='/aboutUs' element={<AboutUs />} />
      <Route path='/worker/register' element={<WorkerRegister />} />
      <Route path='/worker/:workerId' element={<WorkerDetails />} />
      <Route path="*" element={<NotFound />} />
    </ReactRoutes>
  );
};

const Routes = () => {
  return (
    <Router>
      <AppRoutes />
    </Router>
  );
};

export default Routes;