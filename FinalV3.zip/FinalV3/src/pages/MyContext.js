import React, { createContext, useContext, useEffect, useState } from 'react';
import axios from 'axios';
import { Toaster } from 'react-hot-toast';
import toast from 'react-hot-toast';

// Labor and Employer interfaces go here

// Create a context
const MyContext = createContext({
  userWorker: null,
  setUserWorker: () => {},
  userEmployer: null,
  setUserEmployer: () => {},
});

const MyContextProvider = ({ children }) => {
  const [userWorker, setUserWorker] = useState(null);
  const [userEmployer, setUserEmployer] = useState(null);

  useEffect(() => {
    const fetchDataLabor = async () => {
      try {
        const response = await axios.get('http://localhost:5500/api/auth/worker/profile', {
          withCredentials: true,
        });
        if (response.data.success) {
          toast.success(response.data.message);
          setUserWorker(response.data.worker);
        }
      } catch (error) {
        console.error('Error fetching worker data:', error);
      }
    };

    const fetchDataEmployer = async () => {
      try {
        const response = await axios.get('http://localhost:5500/api/auth/employer/profile', {
          withCredentials: true,
        });
        if (response.data.success) {
          toast.success(response.data.message);
          setUserEmployer(response.data.employer);
        }
      } catch (error) {
        console.error('Error fetching employer data:', error);
      }
    };

    fetchDataLabor();
    fetchDataEmployer();
  }, []);

  return (
    <MyContext.Provider value={{ userWorker, setUserWorker, userEmployer, setUserEmployer }}>
      {children}
      <Toaster />
    </MyContext.Provider>
  );
};

const useMyContext = () => useContext(MyContext);

export { MyContext, MyContextProvider, useMyContext };
