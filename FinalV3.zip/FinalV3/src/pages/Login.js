import React, { useState } from 'react';
import LoginForm from '../components/LoginForm';

const Login = () => {
  const [loggedInUserId, setLoggedInUserId] = useState(null);

  const handleLogin = (userId) => {
    setLoggedInUserId(userId);
  };

  return (
    <div>
      {loggedInUserId ? (
        <p>Welcome! User ID: {loggedInUserId}</p>
      ) : (
        <LoginForm onLogin={handleLogin} />
      )}
    </div>
  );
};

export default Login;