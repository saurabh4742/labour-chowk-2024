import React from "react";

const WorkerHome = () => {
    return (
        <>Worker Home</>
    )
}

export default WorkerHome;