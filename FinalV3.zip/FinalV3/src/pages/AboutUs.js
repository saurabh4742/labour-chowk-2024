import React from "react";

const AboutUs = () => {
    return (
        <>
        About Us content comes here if we wanna include it. 
        </>
    )
}

export default AboutUs