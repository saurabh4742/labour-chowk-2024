import React from "react";

const EmployerHome = () => {
    return (
        <>Employer Home</>
    )
}

export default EmployerHome;