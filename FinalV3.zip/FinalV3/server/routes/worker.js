// server/routes/Labor.js
const express = require("express");
const Worker = require("../models/worker.js");
const router = express.Router();

router.get("/all", async (req, res) => {
  try {
    const workers = await Worker.find();
    res.status(200).json(workers);
  } catch (error) {
    console.error("Error fetching Workers:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const WorkerID = req.params.id;

    const worker = await Worker.findById(WorkerID);

    if (!worker) {
      return res.status(404).json({ error: "Worker not found." });
    }
    else{
      return res.status(200).json(worker);
    }
    
  } catch (error) {
    console.error("Error fetching Worker by ID:", error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
});

router.get("/phone/:number", async (req, res) => {
  try {
    const WorkerNumber = req.params.number;

    const Worker = await Worker.findOne({phoneNumber:WorkerNumber });

    if (!Worker) {
      return res.status(404).json({ error: "Worker not found." });
    }
    else{
      return res.status(200).json(Worker);
    }
    
  } catch (error) {
    console.error("Error fetching Worker by ID:", error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
});

// Modify Worker by id
router.put("/modify/:id", async (req, res) => {
  try {
    const { name, address,pincode,availability,experience } = req.body;

    const WorkerId = req.params.id;

    // Check if the Worker with the given ID exists
    const existingWorker = await Worker.findById(WorkerId);

    if (!existingLabor) {
      return res.status(404).json({ error: "Labor not found." });
    }

    existingWorker.name = name;
    existingWorker.address = address;
    existingWorker.pincode = pincode;
    existingWorker.address=address;
    existingWorker.availability=availability;
    existingWorker.experience=experience;

    await existingWorker.save();

    res.status(200).json({ message: "Worker modified successfully." });
  } catch (error) {
    console.error("Error modifying Worker:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

router.delete("/delete/phone/:number", async (req, res) => {
  try {
    const WorkerNumber = req.params.number;

    const existingWorker = await Worker.findOne({ phoneNumber: WorkerNumber });

    if (!existingWorker) {
      return res.status(404).json({ error: "Worker not found." });
    }

    await existingWorker.remove();

    res.status(200).json({ message: "Worker deleted successfully." });
  } catch (error) {
    console.error("Error deleting Worker by phonenumber:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

router.delete("/delete/:id", async (req, res) => {
  try {
    const WorkerId = req.params.id;

    const existingWorker = await Worker.findById(WorkerId);

    if (!existingWorker) {
      return res.status(404).json({ error: "Worker not found." });
    }

    // Delete the Worker from the database
    await existingWorker.remove();

    res.status(200).json({ message: "Worker deleted successfully." });
  } catch (error) {
    console.error("Error deleting Worker by ID:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

module.exports = router;

// For some reason, delete requests are not working, have to check what is the issue persistent.