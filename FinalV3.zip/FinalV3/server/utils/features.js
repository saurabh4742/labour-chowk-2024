const jwt = require('jsonwebtoken');
const {serialize} = require('cookie');
require('dotenv').config();
const Worker=require("../models/worker")
const Employer=require("../models/employer")

const cookieSetterWorker = (res, token, set) => {
  res.setHeader(
    'Set-Cookie',
    serialize('WorkerToken', set ? token : '', {
      path: '/',
      httpOnly: true,
      maxAge: set ? 15 * 24 * 60 * 60 : 0,
    })
  );
};

const cookieSetterEmployer = (res, token, set) => {
    res.setHeader(
      'Set-Cookie',
      serialize('EmployerToken', set ? token : '', {
        path: '/',
        httpOnly: true,
        maxAge: set ? 15 * 24 * 60 * 60 : 0, 
      })
    );
  };

const generateToken = (_id) => {
  return jwt.sign({ _id }, process.env.JWT_SECRET);
};

const checkAuthWorker = async (req) => {
  const cookie = req.headers.cookie;
  if (!cookie) return null;

  const tokens = cookie.split(';').map(c => c.trim().split('='));

  const workerToken = tokens.find(([name]) => name === 'WorkerToken');
  if (!workerToken) return null;

  const token = workerToken[1];
  if (!token) return null;

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    return await Worker.findById(decoded._id);
  } catch (error) {
    return null;
  }
};

const checkAuthEmployer = async (req) => {
  const cookie = req.headers.cookie;
  if (!cookie) return null;

  const tokens = cookie.split(';').map(c => c.trim().split('='));

  const employerToken = tokens.find(([name]) => name === 'EmployerToken');
  if (!employerToken) return null;

  const token = employerToken[1];
  if (!token) return null;

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    return await Employer.findById(decoded._id);
  } catch (error) {
    return null;
  }
};

module.exports = {
  cookieSetterWorker,
  generateToken,
  cookieSetterEmployer,
  checkAuthEmployer,
  checkAuthWorker
};
