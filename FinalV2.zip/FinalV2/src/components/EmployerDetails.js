// src/components/employerDetails.js
import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";

const EmployerDetails = () => {
  const { employerId } = useParams();
  const [employerDetails, setEmployerDetails] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchEmployerDetails = async () => {
      try {
        const response = await fetch(
          `http://localhost:5500/api/employer/${employerId}`
        );
        const data = await response.json();

        if (response.ok) {
          setEmployerDetails(data);
          console.log(data);
        } else {
          setError("employer not found");
        }
      } catch (error) {
        console.error("Error fetching employer details:", error);
        setError("Error fetching employer details");
      }
    };

    fetchEmployerDetails();
  }, [employerId]);

  return (
    <div>
      {error ? (
        <p>{error}</p>
      ) : (
        <>
          <h2>Employer Details</h2>
          {employerDetails ? (
            <>
              <p>ID: {employerDetails._id}</p>
              <p>Name: {employerDetails.username}</p>
              <p>Email: {employerDetails.email}</p>
              <p>Phone: {employerDetails.phoneNumber}</p>
              <p>Address: {employerDetails.address}</p>
              <p>Skills: {employerDetails.skills}</p>
            </>
          ) : (
            <p>Loading...</p>
          )}
        </>
      )}
    </div>
  );
};

export default EmployerDetails;
