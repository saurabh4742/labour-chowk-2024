import React from "react";

const EmployerProfile = () => {
    return (
        <>
        Employer Profile
        </>
    )
}

export default EmployerProfile