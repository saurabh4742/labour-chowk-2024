import React, {useState} from "react";
import { Link,Navigate } from "react-router-dom";
import axios from "axios";
import { useMyContext } from "../MyContext";
import toast from "react-hot-toast";
import Loading from "../Loading";


const EmployerLogin = ({onLogin}) => {

    const {userEmployer, setUserEmployer} = useMyContext()
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [isLoading, setIsLoading] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();

        // Send login request to the server
        const response = await fetch('http://localhost:5500/api/auth/worker/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
        });

        const data = await response.json();

        if (response.ok) {
        // Save the token to local storage or state
        localStorage.setItem('token', data.token);
        onLogin(data.userId);
        } else {
        // Handle login error
        console.error(data.message);
        }
    };

    return (
        <div>
            {userEmployer ? (
                <Navigate to="/employer" />
            ) : isLoading ? (
                <Loading />
            ) : (
                <div className="login-container">
                <h1>Login</h1>
                <form onSubmit={handleSubmit}>
                    <div className="login-form">
                    <input
                        type="email"
                        name="email"
                        placeholder="Email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    />
                    </div>
                    <div className="login-form">
                    <input
                        type="password"
                        name="password"
                        placeholder="Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                    </div>
                    <div className="login-form">
                    <button type="submit" className="login-btn">
                        Login
                    </button>
                    </div>
                </form>
                <p>
                    Don't have an Account? <Link to={"/register"}>SignUp</Link>
                </p>
                </div>
            )}
        </div>
    )
}

export default EmployerLogin