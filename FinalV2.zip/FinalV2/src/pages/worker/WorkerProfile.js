import React from "react";

const WorkerProfile = () => {
    return (
        <>
        Worker Profile
        </>
    )
}

export default WorkerProfile