import React from "react";
import WorkerRegistrationForm from "../../components/worker/WorkerRegistrationForm";

const WorkerRegister = () => {
  return (
    <div>
      <WorkerRegistrationForm />
    </div>
  );
};

export default WorkerRegister;