const mongoose = require('mongoose');

const workerSchema = new mongoose.Schema({
  name: { type: String, required: true },
  password: { type: String, required: true },
  phoneNumber: { type: String, required: true, unique: true },
  pincode: { type: String, required: true },
  address: { type: String, required: true },
  skills: [{ type: String ,required: true}],
  experience:{
    type: String, required: true
  },
  availability: { type: Boolean } 
});

const Worker = mongoose.model('Worker', workerSchema);

module.exports = Worker;
