const express = require("express");
const Worker = require("../models/worker.js");
const router = express.Router();
const bcrypt = require("bcrypt");
const { cookieSetterWorker, generateToken ,checkAuthWorker} = require("../utils/features.js");
require('dotenv').config();

//profile
router.get('/profile', async (req, res)=>{
  try{
    const worker = await checkAuthWorker(req);
    if (!worker) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    res.status(200).json({
      success:true,
      worker
    })
  }
  catch (error) {
    console.error('Error in profile fetching:', error);
    return res.status(500).json({ error: 'Internal Server Error' });
  }
}
)

router.get('/logout', async (req, res)=>{
  try{
      cookieSetterWorker(res,null,false)
      res.status(200).json({succes:true,message:"Loged out"})
  }
  catch (error) {
    console.error('Error logging out as Worker:', error);
    return res.status(500).json({ error: 'Internal Server Error' });
  }
}
)

router.post('/login', async (req, res) => {
    try {
      const { phoneNumber, password } = req.body;
  
      // Check if the Worker with the given phone number exists
      const worker = await Worker.findOne({ phoneNumber });
  
      if (!worker) {
        return res.status(400).json({ error: 'Worker not found.' });
      }
  
      // Check if the password matches
      const isPasswordValid = await bcrypt.compare(password, worker.password);
  
      if (!isPasswordValid) {
        return res.status(400).json({ error: 'Invalid credentials.' });
      }
  
      // Create a JWT token with the Worker ID
      const token=generateToken(worker._id)
      cookieSetterWorker(res,token,true)
      // Set the token as a cookie
  
      // Send a success message
      return res.status(200).json({ message: `Welcome back ! ${worker.name}`, worker});
    } catch (error) {
      console.error('Error logging in Worker:', error);
      return res.status(500).json({ error: 'Internal Server Error' });
    }
  });

  // Worker registration route

  router.post("/register", async (req, res) => {
    try {
      const { name, password, phoneNumber, address, pincode, skills ,experience } = req.body;
  
      // Validate required fields
      if (!name || !password || !phoneNumber || !address || !pincode || !skills || !experience) {
        return res.status(400).json({ error: "All fields are required." });
      }
  
      // Validate phone number format
      const phoneRegex = /^\d{10}$/;
      if (!phoneRegex.test(phoneNumber)) {
        return res.status(400).json({ error: "phone number should contain 10 digit only." });
      }
  
      // Check if user with the same phone number already exists
      let worker = await Worker.findOne({ phoneNumber });
      if (worker) {
        return res.status(400).json({ error: "Worker already registered with this phonenumber" });
      }
  
      const hashedPassword = await bcrypt.hash(password, 10);
  
      // Create a new Worker
      worker = await Worker.create({
        name,
        password: hashedPassword,
        phoneNumber,
        pincode,
        address,
        skills,
        experience,
        availability: true
      });
      const token=generateToken(worker._id)
      cookieSetterWorker(res,token,true)
  
      res.status(201).json({ message: "Worker registered successfully.", worker });
    } catch (error) {
      console.error("Error registering Worker:", error);
      res.status(500).json({ error: "Internal Server Error" });
    }
  });

  module.exports = router;